for ((i=1 ; i<=100; i++))
do
	echo $i
done
if [ $i
