read year
result=0

if [($year/4)==0]
then
	echo "leap year"
else
	echo "leap year"
fi

